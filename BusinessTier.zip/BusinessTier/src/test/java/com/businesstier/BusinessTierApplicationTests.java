package com.businesstier;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusinessTierApplicationTests {

   /* @Test
    void contextLoads() {
    }*/

}
